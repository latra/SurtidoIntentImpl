package com.example.surtidointentimpl;


import android.Manifest;
import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

	    Button btn1 = findViewById(R.id.button1);
	    Button btn2 = findViewById(R.id.button2);
	    Button btn3 = findViewById(R.id.button3);
	    Button btn4 = findViewById(R.id.button4);
	    Button btn5 = findViewById(R.id.button5);
	    Button btn6 = findViewById(R.id.button6);

	    btn1.setOnClickListener(this);
	    btn2.setOnClickListener(this);
	    btn3.setOnClickListener(this);
	    btn4.setOnClickListener(this);
	    btn5.setOnClickListener(this);
	    btn6.setOnClickListener(this);

		if (Build.VERSION.SDK_INT >= 23)
			if (! ckeckPermissions())
			  requestPermissions();
	}

	public void onClick (View v) {
		Intent in;
		final String lat = "41.60788";
		final String lon = "0.623333";
		final String url = "http://www.eps.udl.cat/ca/";
		final String adressa = "Carrer de Jaume II, 69, Lleida";
		final String textoABuscar = "escuela politecnica superior";

		switch (v.getId()) {
			case R.id.button1:
				Toast.makeText(this, getString(R.string.opcio1), Toast.LENGTH_LONG).show();
				in = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + lat + ',' + lon));
				startActivity(in);
				break;
			case R.id.button2:
				Toast.makeText(this, getString(R.string.opcio2), Toast.LENGTH_LONG).show();
				in = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + adressa));
				startActivity(in);
				break;
			case R.id.button3:
				Toast.makeText(this, getString(R.string.opcio3), Toast.LENGTH_LONG).show();
				in = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
				startActivity(in);
				break;
			case R.id.button4:
				Toast.makeText(this, getString(R.string.opcio4), Toast.LENGTH_LONG).show();
				//in = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com/search?q=" + "escola politecnica superior UdL"));
				in = new Intent(Intent.ACTION_WEB_SEARCH);
				in.putExtra(SearchManager.QUERY, textoABuscar);
				startActivity(in);
				break;
			case R.id.button5:
				Toast.makeText(this, "Llamando al Tlfn.", Toast.LENGTH_LONG).show();
				in = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + getText(R.string.telef)));
				startActivity(in);
				break;
			case R.id.button6:
				Toast.makeText(this, getString(R.string.opcio6), Toast.LENGTH_LONG).show();
				in = new Intent(Intent.ACTION_VIEW);
				in.setData(ContactsContract.Contacts.CONTENT_URI);
				startActivity(in);
				break;
			}
	}


	@Override
	protected void onResume() {
		super.onResume();
	}

	private boolean ckeckPermissions() {
		//if (Build.VERSION.SDK_INT >= 23) {
			//String[] PERMISSIONS = {android.Manifest.permission.CALL_PHONE};
			if (ActivityCompat.checkSelfPermission(getApplicationContext(),
					Manifest.permission.CALL_PHONE) ==
					PackageManager.PERMISSION_GRANTED)
				return true;
			else
				return false;
		    //}
		//else
			//return true;
	}

	private void requestPermissions() {
		ActivityCompat.requestPermissions(MainActivity.this,
				new String[]{Manifest.permission.CALL_PHONE},
				0);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
}
